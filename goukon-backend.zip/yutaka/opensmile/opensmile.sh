#!/bin/sh

sox "/home/yutaka/opensmile/result.wav" -b 16 "/home/yutaka/opensmile/output.wav"
rm -rf /home/yutaka/opensmile/player.arff
rm -rf /home/yutaka/opensmile/smile.log
SMILExtract -C /home/yutaka/opensmile-2.3.0.2/config/IS12_speaker_trait.conf -I /home/yutaka/opensmile/output.wav -O /home/yutaka/opensmile/player.arff -class 0
python3 /home/yutaka/opensmile/outside-scripts/main.py
mv "/home/yutaka/opensmile/output.wav" "/home/yutaka/opensmile/wav/output$(date +%Y%m%d%H%M%S).wav"
mv "/home/yutaka/opensmile/text.txt" "/home/yutaka/opensmile/wav/output$(date +%Y%m%d%H%M%S).txt"
