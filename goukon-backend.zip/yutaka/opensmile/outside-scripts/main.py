import atr_estimate
import TextEdit2
import os
from sklearn.linear_model import LogisticRegression
import numpy as np
from sklearn.feature_selection import SelectKBest,f_regression,f_classif
from sklearn.linear_model import LinearRegression,Ridge,Lasso
from scipy.io import arff
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold
from sklearn import preprocessing
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import LeaveOneOut
import scipy.stats
import csv
import pprint
from sklearn.metrics import accuracy_score

def estimate0(arff_path):
        dataset, meta = arff.loadarff("/home/yutaka/opensmile/outside-scripts/cluster/cluster0.arff")
        d=np.asarray(dataset.tolist(),dtype=float)
        player_dataset,player_meta = arff.loadarff(arff_path)
        player_ds=np.asarray(player_dataset.tolist(),dtype=float)
	#print(player_ds)
	#print(d)
        ds = np.append(d,player_ds,axis=0)
        selectNameList = [
		"audSpec_Rfilt_sma[5]_quartile2",
		"pcm_fftMag_mfcc_sma[13]_lpc0",
		"pcm_fftMag_mfcc_sma[13]_lpc3",
		"audSpec_Rfilt_sma_de[23]_quartile3",
		"audSpec_Rfilt_sma_de[23]_iqr2-3",
		"pcm_fftMag_mfcc_sma_de[6]_iqr1-2",
		"pcm_fftMag_mfcc_sma_de[6]_lpc0",
		"pcm_fftMag_mfcc_sma_de[12]_skewness",
		"pcm_fftMag_mfcc_sma_de[12]_upleveltime75",
		"pcm_fftMag_mfcc_sma_de[12]_downleveltime75",
		"pcm_fftMag_mfcc_sma_de[13]_lpc0",
		"F0final_sma_upleveltime25",
		"F0final_sma_upleveltime50",
		"F0final_sma_upleveltime75",
		"audSpec_Rfilt_sma[20]_minRangeRel",
		"pcm_fftMag_mfcc_sma[3]_qregc2",
		"pcm_fftMag_mfcc_sma[7]_stddevRisingSlope",
		"pcm_fftMag_mfcc_sma[12]_qregc1",
	]
        target=ds[:,-1]
	#print(target.shape)
        X=ds[:,:-1]
	#正規化 有効特徴量比較のため
        train = scipy.stats.zscore(X,ddof=1)
        X_new = SelectKBest(score_func=f_regression, k=15)	
        tmpX = train[:-1]
        tmpY = target[:-1]
        X_new.fit_transform(tmpX,tmpY)
	#print(train.shape)
        X_selected = X_new.transform(train)
	#どの特徴量が選ばれたか
        name_list= meta.names()
        mask = X_new.get_support()
        list = []
        for f,w in zip(name_list,mask):
            if w :
                list.append(f)
        lr = LinearRegression()
        lr.fit(X_selected[:-1],target[:-1])
        result=[]
        true_X=[]
        sum = 0
        for f,w in zip(X_selected[-1],lr.coef_):
            sum = sum + f*w
            true_X.append(f*w)
        tmpStr = "intercept",lr.intercept_
        result.append(tmpStr)
        for f,w in zip(list,true_X):
            str = f,":",w
            result.append(str)
        tmpStr="sum",sum
        result.append(tmpStr)
        tmpStr="intercept",lr.intercept_
        result.append(tmpStr)
        # for f in X_selected[-1]:
        #    print(f)
        #print("accuracy:",lr.score(X_selected[:-1],target[:-1]))
	#player-output.arff
	# class 0 remove
	#print(X_selected[-1])
        D = []
        D.append(X_selected[-1])
        score = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5)
        score2 = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5,scoring="neg_root_mean_squared_error") 
        #print("score:",score.mean())
        #print("Nrmse:",score2.mean())
        #result = []
        result.append(lr.predict(D))
        return result
	
def estimate1(arff_path):
        dataset, meta = arff.loadarff("/home/yutaka/opensmile/outside-scripts/cluster/cluster1.arff")
        d=np.asarray(dataset.tolist(),dtype=float)
        player_dataset,player_meta = arff.loadarff(arff_path)
        player_ds=np.asarray(player_dataset.tolist(),dtype=float)
	#print(player_ds)
	#print(d)
        ds = np.append(d,player_ds,axis=0)
        selectNameList = [
		"audSpec_Rfilt_sma[5]_quartile2",
		"pcm_fftMag_mfcc_sma[13]_lpc0",
		"pcm_fftMag_mfcc_sma[13]_lpc3",
		"audSpec_Rfilt_sma_de[23]_quartile3",
		"audSpec_Rfilt_sma_de[23]_iqr2-3",
		"pcm_fftMag_mfcc_sma_de[6]_iqr1-2",
		"pcm_fftMag_mfcc_sma_de[6]_lpc0",
		"pcm_fftMag_mfcc_sma_de[12]_skewness",
		"pcm_fftMag_mfcc_sma_de[12]_upleveltime75",
		"pcm_fftMag_mfcc_sma_de[12]_downleveltime75",
		"pcm_fftMag_mfcc_sma_de[13]_lpc0",
		"F0final_sma_upleveltime25",
		"F0final_sma_upleveltime50",
		"F0final_sma_upleveltime75",
		"audSpec_Rfilt_sma[20]_minRangeRel",
		"pcm_fftMag_mfcc_sma[3]_qregc2",
		"pcm_fftMag_mfcc_sma[7]_stddevRisingSlope",
		"pcm_fftMag_mfcc_sma[12]_qregc1",
	]
        target=ds[:,-1]
	#print(target.shape)
        X=ds[:,:-1]
	#正規化 有効特徴量比較のため
        train = scipy.stats.zscore(X,ddof=1)
        X_new = SelectKBest(score_func=f_regression, k=15)	
        tmpX = train[:-1]
        tmpY = target[:-1]
        X_new.fit_transform(tmpX,tmpY)
	#print(train.shape)
        X_selected = X_new.transform(train)
	#どの特徴量が選ばれたか
        name_list= meta.names()
        mask = X_new.get_support()
        list = []
        for f,w in zip(name_list,mask):
            if w :
                list.append(f)
        lr = LinearRegression()
        lr.fit(X_selected[:-1],target[:-1])
        result=[]
        true_X=[]
        sum = 0
        for f,w in zip(X_selected[-1],lr.coef_):
            sum = sum + f*w
            true_X.append(f*w)
        tmpStr = "intercept",lr.intercept_
        result.append(tmpStr)
        for f,w in zip(list,true_X):
            str = f,":",w
            result.append(str)
        tmpStr="sum",sum
        result.append(tmpStr)
        tmpStr="intercept",lr.intercept_
        result.append(tmpStr)
        # for f in X_selected[-1]:
        #    print(f)
        #print("accuracy:",lr.score(X_selected[:-1],target[:-1]))
	#player-output.arff
	# class 0 remove
	#print(X_selected[-1])
        D = []
        D.append(X_selected[-1])
        score = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5)
        score2 = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5,scoring="neg_root_mean_squared_error") 
        #print("score:",score.mean())
        #print("Nrmse:",score2.mean())
        #result = []
        result.append(lr.predict(D))
        return result

def estimate2(arff_path):
        dataset, meta = arff.loadarff("/home/yutaka/opensmile/outside-scripts/cluster/cluster2.arff")

        d=np.asarray(dataset.tolist(),dtype=float)
        player_dataset,player_meta = arff.loadarff(arff_path)
        player_ds=np.asarray(player_dataset.tolist(),dtype=float)
	#print(player_ds)
	#print(d)
        ds = np.append(d,player_ds,axis=0)
        selectNameList = [
		"audSpec_Rfilt_sma[5]_quartile2",
		"pcm_fftMag_mfcc_sma[13]_lpc0",
		"pcm_fftMag_mfcc_sma[13]_lpc3",
		"audSpec_Rfilt_sma_de[23]_quartile3",
		"audSpec_Rfilt_sma_de[23]_iqr2-3",
		"pcm_fftMag_mfcc_sma_de[6]_iqr1-2",
		"pcm_fftMag_mfcc_sma_de[6]_lpc0",
		"pcm_fftMag_mfcc_sma_de[12]_skewness",
		"pcm_fftMag_mfcc_sma_de[12]_upleveltime75",
		"pcm_fftMag_mfcc_sma_de[12]_downleveltime75",
		"pcm_fftMag_mfcc_sma_de[13]_lpc0",
		"F0final_sma_upleveltime25",
		"F0final_sma_upleveltime50",
		"F0final_sma_upleveltime75",
		"audSpec_Rfilt_sma[20]_minRangeRel",
		"pcm_fftMag_mfcc_sma[3]_qregc2",
		"pcm_fftMag_mfcc_sma[7]_stddevRisingSlope",
		"pcm_fftMag_mfcc_sma[12]_qregc1",
	]
        target=ds[:,-1]
	#print(target.shape)
        X=ds[:,:-1]
	#正規化 有効特徴量比較のため
        train = scipy.stats.zscore(X,ddof=1)
        X_new = SelectKBest(score_func=f_regression, k=15)	
        tmpX = train[:-1]
        tmpY = target[:-1]
        X_new.fit_transform(tmpX,tmpY)
	#print(train.shape)
        X_selected = X_new.transform(train)
	#どの特徴量が選ばれたか
        name_list= meta.names()
        mask = X_new.get_support()
        list = []
        for f,w in zip(name_list,mask):
            if w :
                list.append(f)
        lr = LinearRegression()
        lr.fit(X_selected[:-1],target[:-1])
        result=[]
        true_X=[]
        sum = 0
        for f,w in zip(X_selected[-1],lr.coef_):
            sum = sum + f*w
            true_X.append(f*w)
        tmpStr = "intercept",lr.intercept_
        result.append(tmpStr)
        for f,w in zip(list,true_X):
            str = f,":",w
            result.append(str)
        tmpStr="sum",sum
        result.append(tmpStr)
        tmpStr="intercept",lr.intercept_
        result.append(tmpStr)
        # for f in X_selected[-1]:
        #    print(f)
        #print("accuracy:",lr.score(X_selected[:-1],target[:-1]))
	#player-output.arff
	# class 0 remove
	#print(X_selected[-1])
        D = []
        D.append(X_selected[-1])
        score = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5)
        score2 = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5,scoring="neg_root_mean_squared_error") 
        #print("score:",score.mean())
        #print("Nrmse:",score2.mean())
    
        result.append(lr.predict(D))
        return result

def estimate3(arff_path):
        dataset, meta = arff.loadarff("/home/yutaka/opensmile/outside-scripts/cluster/cluster3.arff")
        d=np.asarray(dataset.tolist(),dtype=float)
        player_dataset,player_meta = arff.loadarff(arff_path)
        player_ds=np.asarray(player_dataset.tolist(),dtype=float)
	#print(player_ds)
	#print(d)
        ds = np.append(d,player_ds,axis=0)
        selectNameList = [
		"audSpec_Rfilt_sma[5]_quartile2",
		"pcm_fftMag_mfcc_sma[13]_lpc0",
		"pcm_fftMag_mfcc_sma[13]_lpc3",
		"audSpec_Rfilt_sma_de[23]_quartile3",
		"audSpec_Rfilt_sma_de[23]_iqr2-3",
		"pcm_fftMag_mfcc_sma_de[6]_iqr1-2",
		"pcm_fftMag_mfcc_sma_de[6]_lpc0",
		"pcm_fftMag_mfcc_sma_de[12]_skewness",
		"pcm_fftMag_mfcc_sma_de[12]_upleveltime75",
		"pcm_fftMag_mfcc_sma_de[12]_downleveltime75",
		"pcm_fftMag_mfcc_sma_de[13]_lpc0",
		"F0final_sma_upleveltime25",
		"F0final_sma_upleveltime50",
		"F0final_sma_upleveltime75",
		"audSpec_Rfilt_sma[20]_minRangeRel",
		"pcm_fftMag_mfcc_sma[3]_qregc2",
		"pcm_fftMag_mfcc_sma[7]_stddevRisingSlope",
		"pcm_fftMag_mfcc_sma[12]_qregc1",
	]
        target=ds[:,-1]
	#print(target.shape)
        X=ds[:,:-1]
	#正規化 有効特徴量比較のため
        train = scipy.stats.zscore(X,ddof=1)
        X_new = SelectKBest(score_func=f_regression, k=15)	
        tmpX = train[:-1]
        tmpY = target[:-1]
        X_new.fit_transform(tmpX,tmpY)
	#print(train.shape)
        X_selected = X_new.transform(train)
	#どの特徴量が選ばれたか
        name_list= meta.names()
        mask = X_new.get_support()
        list = []
        for f,w in zip(name_list,mask):
            if w :
                list.append(f)
        lr = LinearRegression()
        lr.fit(X_selected[:-1],target[:-1])
        result=[]
        true_X=[]
        sum = 0
        for f,w in zip(X_selected[-1],lr.coef_):
            sum = sum + f*w
            true_X.append(f*w)
        tmpStr = "intercept",lr.intercept_
        result.append(tmpStr)
        for f,w in zip(list,true_X):
            str = f,":",w
            result.append(str)
        tmpStr="sum",sum
        result.append(tmpStr)
        tmpStr="intercept",lr.intercept_
        result.append(tmpStr)
        # for f in X_selected[-1]:
        #    print(f)
        #print("accuracy:",lr.score(X_selected[:-1],target[:-1]))
	#player-output.arff
	# class 0 remove
	#print(X_selected[-1])
        D = []
        D.append(X_selected[-1])
        score = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5)
        score2 = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5,scoring="neg_root_mean_squared_error") 
        #print("score:",score.mean())
        #print("Nrmse:",score2.mean())
        result.append(lr.predict(D))
        return result


def estimate(arff_path):
        dataset, meta = arff.loadarff("/home/yutaka/opensmile/outside-scripts/output.arff")

        d=np.asarray(dataset.tolist(),dtype=float)
        player_dataset,player_meta = arff.loadarff(arff_path)
        player_ds=np.asarray(player_dataset.tolist(),dtype=float)
	#print(player_ds)
	#print(d)
        ds = np.append(d,player_ds,axis=0)
        selectNameList = [
		"audSpec_Rfilt_sma[5]_quartile2",
		"pcm_fftMag_mfcc_sma[13]_lpc0",
		"pcm_fftMag_mfcc_sma[13]_lpc3",
		"audSpec_Rfilt_sma_de[23]_quartile3",
		"audSpec_Rfilt_sma_de[23]_iqr2-3",
		"pcm_fftMag_mfcc_sma_de[6]_iqr1-2",
		"pcm_fftMag_mfcc_sma_de[6]_lpc0",
		"pcm_fftMag_mfcc_sma_de[12]_skewness",
		"pcm_fftMag_mfcc_sma_de[12]_upleveltime75",
		"pcm_fftMag_mfcc_sma_de[12]_downleveltime75",
		"pcm_fftMag_mfcc_sma_de[13]_lpc0",
		"F0final_sma_upleveltime25",
		"F0final_sma_upleveltime50",
		"F0final_sma_upleveltime75",
		"audSpec_Rfilt_sma[20]_minRangeRel",
		"pcm_fftMag_mfcc_sma[3]_qregc2",
		"pcm_fftMag_mfcc_sma[7]_stddevRisingSlope",
		"pcm_fftMag_mfcc_sma[12]_qregc1",
	]
        target=ds[:,-1]
	#print(target.shape)
        X=ds[:,:-1]
	#正規化 有効特徴量比較のため
        train = scipy.stats.zscore(X,ddof=1)
        X_new = SelectKBest(score_func=f_regression, k=15)	
        tmpX = train[:-1]
        tmpY = target[:-1]
        X_new.fit_transform(tmpX,tmpY)
	#print(train.shape)
        X_selected = X_new.transform(train)
	#どの特徴量が選ばれたか
        name_list= meta.names()
        mask = X_new.get_support()
        list = []
        for f,w in zip(name_list,mask):
            if w :
                list.append(f)
        lr = LinearRegression()
        lr.fit(X_selected[:-1],target[:-1])
        result=[]
        true_X=[]
        sum = 0
        for f,w in zip(X_selected[-1],lr.coef_):
            sum = sum + f*w
            true_X.append(f*w)
        tmpStr = "intercept",lr.intercept_
        result.append(tmpStr)
        for f,w in zip(list,true_X):
            str = f,":",w
            result.append(str)
        tmpStr="sum",sum
        result.append(tmpStr)
        tmpStr="intercept",lr.intercept_
        result.append(tmpStr)
        # for f in X_selected[-1]:
        #    print(f)
        print("accuracy:",lr.score(X_selected[:-1],target[:-1]))
	#player-output.arff
	# class 0 remove
	#print(X_selected[-1])
        D = []
        D.append(X_selected[-1])
        score = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5)
        score2 = cross_val_score(lr,X_selected[:-1],target[:-1],cv=5,scoring="neg_root_mean_squared_error") 
        print("score:",score.mean())
        print("Nrmse:",score2.mean())
        #result = []
        result.append(lr.predict(D))
        return result

def edit(path):
	#IS2012用
	file1=open(path,'r',encoding='utf-8')
	result=[]
	for line in file1:
		result.append(line)
	data=result[5764:]
	data_atr=result[:5764]
	arff=[]
	atr=[]
	for line2 in data:
		arff.append(line2.lstrip("'unknown,'"))
	for line3 in data_atr:
		if line3==result[2]:
			#print("成功だ!")
			continue
		atr.append(line3)
	atr.append(arff)
	with open("/home/yutaka/opensmile/outside-scripts/result.arff", mode='w') as w:
	#with open(path, mode='w') as w:

	 	for wr in atr:
	 		w.writelines(wr)
	w.close()
	file1.close()

path = "/home/yutaka/opensmile/player.arff"

#path0 = "/home/yutaka/opensmile/outside-scripts/cluster/cluster0.arff"
#path1 = "/home/yutaka/opensmile/outside-scripts/cluster/cluster1.arff"
#path2 = "/home/yutaka/opensmile/outside-scripts/cluster/cluster2.arff"
#path3 = "/home/yutaka/opensmile/outside-scripts/cluster/cluster3.arff"

edit(path)
#edit(path1)
#edit(path2)
#edit(path3)

path = "/home/yutaka/opensmile/outside-scripts/result.arff"

result = []
result = estimate(path)

result0 = []
result0 = estimate0(path)

result1 = []
result1 = estimate1(path)

result2 = []
result2 = estimate2(path)

result3 = []
result3 = estimate3(path)


with open("/home/yutaka/opensmile/text.txt", mode='w') as w:
    for f in result:
        print(f)
        w.write(str(f))
w.close()


with open("/home/yutaka/opensmile/text.txt0", mode='w') as w:
    for f in result0:
        print(f)
        w.write(str(f))
w.close()


with open("/home/yutaka/opensmile/text.txt1", mode='w') as w:
    for f in result1:
        print(f)
        w.write(str(f))
w.close()


with open("/home/yutaka/opensmile/text.txt2", mode='w') as w:
    for f in result2:
        print(f)
        w.write(str(f))
w.close()


with open("/home/yutaka/opensmile/text.txt3", mode='w') as w:
    for f in result3:
        print(f)
        w.write(str(f))
w.close()



